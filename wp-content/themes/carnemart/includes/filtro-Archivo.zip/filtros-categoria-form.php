<?php
// Para usar la categoría actual (si estás en /product-category/…)
$current_category = is_tax('product_cat') ? get_queried_object() : null;
?>

<form id="filtros-categorias" class="filter-container" method="GET">
   <?php
   // Subcategorías de la categoría actual (o root si no estás en una)
   $subcategories = get_terms(array(
      'taxonomy'   => 'product_cat',
      'hide_empty' => true,
      'parent'     => $current_category ? $current_category->term_id : 0
   ));
   if (!empty($subcategories)) : ?>
      <div class="filter-group">
         <div class="filter-title" data-toggle="filter" data-target="#filter-subcategories">
            Categorías <i class="bi bi-chevron-down"></i>
         </div>
         <ul class="filter-content" id="filter-subcategories">
            <?php foreach ($subcategories as $subcategory) : ?>
               <li>
                  <input type="checkbox"
                     class="form-check-input"
                     id="cat-<?php echo esc_attr($subcategory->slug); ?>"
                     name="categorias[]"
                     value="<?php echo esc_attr($subcategory->slug); ?>"
                     <?php
                     $categorias = isset($_GET['categorias']) ? $_GET['categorias'] : [];
                     if (!is_array($categorias)) $categorias = explode(',', $categorias);
                     $categorias = array_map('sanitize_title', $categorias);
                     checked(in_array($subcategory->slug, $categorias, true));
                     ?>>
                  <label class="form-check-label" for="cat-<?php echo esc_attr($subcategory->slug); ?>">
                     <?php echo esc_html($subcategory->name); ?> (<?php echo esc_html($subcategory->count); ?>)
                  </label>
               </li>
            <?php endforeach; ?>
         </ul>
      </div>
   <?php endif; ?>

   <?php
   // Giros de negocio = tags de producto
   $product_tags = get_terms(array(
      'taxonomy'   => 'product_tag',
      'hide_empty' => true,
   ));
   if (!empty($product_tags) && !is_wp_error($product_tags)) : ?>
      <div class="filter-group">
         <div class="filter-title" data-toggle="filter" data-target="#filter-tags">
            Giros de negocio <i class="bi bi-chevron-down"></i>
         </div>
         <ul class="filter-content" id="filter-tags">
            <?php
            // Lee tanto 'etiquetas' como 'product_tag' por compatibilidad
            $etiquetas = isset($_GET['etiquetas']) ? $_GET['etiquetas'] : ($_GET['product_tag'] ?? []);
            if (!is_array($etiquetas)) $etiquetas = explode(',', $etiquetas);
            $etiquetas = array_map('sanitize_title', $etiquetas);
            ?>
            <?php foreach ($product_tags as $tag) : ?>
               <li>
                  <input type="checkbox"
                     class="form-check-input"
                     id="tag-<?php echo esc_attr($tag->slug); ?>"
                     name="etiquetas[]"
                     value="<?php echo esc_attr($tag->slug); ?>"
                     <?php checked(in_array($tag->slug, $etiquetas, true)); ?>>
                  <label class="form-check-label" for="tag-<?php echo esc_attr($tag->slug); ?>">
                     <?php echo esc_html($tag->name); ?> (<?php echo esc_html($tag->count); ?>)
                  </label>
               </li>
            <?php endforeach; ?>
         </ul>
      </div>
   <?php endif; ?>

   <?php
   // Rango de precios (Woo tomará min_price/max_price solo)
   $price_range = get_filtered_price_range(); // <-- tu helper existente
   $min_price   = floor($price_range['min']);
   $max_price   = ceil($price_range['max']);

   // Persistencia visual desde GET
   $min_sel = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? (float) $_GET['min_price'] : $min_price;
   $max_sel = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? (float) $_GET['max_price'] : $max_price;
   ?>
   <div class="filter-group">
      <div class="filter-title" data-toggle="filter" data-target="#filter-tipo-04">
         Rango de precios <i class="bi bi-chevron-down"></i>
      </div>
      <div class="filter-content" id="filter-tipo-04">
         <div class="box-range-price">
            <small>Selecciona el rango de precios</small>
            <div class="range-slider">
               <input type="range"
                  min="<?php echo esc_attr($min_price); ?>"
                  max="<?php echo esc_attr($max_price); ?>"
                  value="<?php echo esc_attr($min_sel); ?>"
                  id="min-price"
                  name="min_price" />
               <input type="range"
                  min="<?php echo esc_attr($min_price); ?>"
                  max="<?php echo esc_attr($max_price); ?>"
                  value="<?php echo esc_attr($max_sel); ?>"
                  id="max-price"
                  name="max_price" />
               <div class="slider-track"></div>
            </div>
            <div class="price-labels">
               <span id="min-price-label">$<?php echo number_format($min_sel, 0, '.', ','); ?></span>
               <span id="max-price-label">$<?php echo number_format($max_sel, 0, '.', ','); ?></span>
            </div>
         </div>
      </div>
   </div>

   <button type="submit" class="cta-inline mt-3">FILTRAR</button>
</form>

<?php
/* =========================
 * TARJETA “FILTROS ACTIVOS” (chips quitables sin JS)
 * ========================= */

// Helpers locales
$af_get = function ($key) {
   if (!isset($_GET[$key]) || $_GET[$key] === '') return [];
   $v = $_GET[$key];
   if (is_array($v)) return array_map('sanitize_title', $v);
   return array_map('sanitize_title', array_filter(explode(',', $v)));
};

$categorias_sel = $af_get('categorias');
$etiquetas_sel  = array_values(array_unique(array_merge($af_get('etiquetas'), $af_get('product_tag')))); // lee ambos
$min_q = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? (float) $_GET['min_price'] : null;
$max_q = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? (float) $_GET['max_price'] : null;

$cat_terms = !empty($categorias_sel) ? get_terms(['taxonomy' => 'product_cat', 'slug' => $categorias_sel, 'hide_empty' => false]) : [];
$tag_terms = !empty($etiquetas_sel)  ? get_terms(['taxonomy' => 'product_tag', 'slug' => $etiquetas_sel, 'hide_empty' => false])  : [];

$has_any = (!empty($categorias_sel) || !empty($etiquetas_sel) || $min_q !== null || $max_q !== null);

// Base URL (tienda o categoría actual)
if (is_shop()) {
   $af_base = get_permalink(wc_get_page_id('shop'));
} elseif ($current_category && isset($current_category->term_id)) {
   $af_base = get_term_link($current_category->term_id);
} else {
   $af_base = get_post_type_archive_link('product');
}

// Helpers para quitar chips
$af_url_without_terms_in_keys = function ($keys, $slug) use ($af_base) {
   $new = $_GET;
   foreach ((array)$keys as $param) {
      if (!isset($new[$param])) continue;
      $arr = is_array($new[$param]) ? $new[$param] : explode(',', $new[$param]);
      $arr = array_map('sanitize_title', $arr);
      $arr = array_values(array_diff($arr, [$slug]));
      if (empty($arr)) unset($new[$param]);
      else $new[$param] = implode(',', $arr);
   }
   unset($new['paged'], $new['page']);
   return esc_url(add_query_arg($new, $af_base));
};
$af_url_without_price = function () use ($af_base) {
   $new = $_GET;
   unset($new['min_price'], $new['max_price'], $new['paged'], $new['page']);
   return esc_url(add_query_arg($new, $af_base));
};
?>

<div class="active-filters-card <?php echo $has_any ? 'is-filled' : 'is-empty'; ?>" aria-label="Filtros activos">
   <div class="af-header">
      <strong class="af-title">Filtros activos</strong>
      <a class="af-clear-all<?php echo $has_any ? '' : ' is-disabled'; ?>"
         href="<?php echo $has_any ? esc_url($af_base) : 'javascript:void(0)'; ?>"
         <?php echo $has_any ? '' : 'aria-disabled="true"'; ?>>
         Limpiar todo
      </a>
   </div>

   <div class="af-body">
      <!-- Categoría -->
      <div class="af-row">
         <strong class="af-label">Categoría:</strong>
         <div class="af-chips">
            <?php if (!empty($cat_terms) && !is_wp_error($cat_terms)) : ?>
               <?php foreach ($cat_terms as $t): ?>
                  <a class="af-chip" href="<?php echo $af_url_without_terms_in_keys('categorias', $t->slug); ?>">
                     <?php echo esc_html($t->name); ?>
                     <span class="af-x" aria-hidden="true">&times;</span>
                     <span class="screen-reader-text">Quitar categoría <?php echo esc_html($t->name); ?></span>
                  </a>
               <?php endforeach; ?>
            <?php else: ?>
               <span class="af-placeholder">Sin selección</span>
            <?php endif; ?>
         </div>
      </div>

      <!-- Tags -->
      <div class="af-row">
         <strong class="af-label">Tags:</strong>
         <div class="af-chips">
            <?php if (!empty($tag_terms) && !is_wp_error($tag_terms)) : ?>
               <?php foreach ($tag_terms as $t): ?>
                  <a class="af-chip af-chip--gray" href="<?php
                                                         // Quita el slug tanto de 'etiquetas' como de 'product_tag', por compatibilidad
                                                         echo $af_url_without_terms_in_keys(array('etiquetas', 'product_tag'), $t->slug);
                                                         ?>">
                     <?php echo esc_html($t->name); ?>
                     <span class="af-x" aria-hidden="true">&times;</span>
                     <span class="screen-reader-text">Quitar tag <?php echo esc_html($t->name); ?></span>
                  </a>
               <?php endforeach; ?>
            <?php else: ?>
               <span class="af-placeholder">Sin selección</span>
            <?php endif; ?>
         </div>
      </div>

      <!-- Precio -->
      <div class="af-row">
         <strong class="af-label">Precio:</strong>
         <div class="af-chips">
            <?php if ($min_q !== null || $max_q !== null) : ?>
               <?php
               $min_txt = $min_q !== null ? '$' . number_format($min_q, 0, '.', ',') : 'min';
               $max_txt = $max_q !== null ? '$' . number_format($max_q, 0, '.', ',') : 'max';
               ?>
               <a class="af-chip af-chip--yellow" href="<?php echo $af_url_without_price(); ?>">
                  <?php echo esc_html($min_txt . ' – ' . $max_txt); ?>
                  <span class="af-x" aria-hidden="true">&times;</span>
                  <span class="screen-reader-text">Quitar filtro de precio</span>
               </a>
            <?php else: ?>
               <span class="af-placeholder">Sin selección</span>
            <?php endif; ?>
         </div>
      </div>
   </div>
</div>

<!-- DEBUG temporal (bórralo cuando confirmes) -->
<?php /*
echo '<pre style="background:#111;color:#0f0;padding:8px;white-space:pre-wrap">';
print_r($_GET);
echo '</pre>';
*/ ?>

<style>
   .active-filters-card {
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 12px 14px;
      margin-top: 14px;
      background: #fff;
      max-width: 460px
   }

   .af-header {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 8px;
      flex-direction: column
   }

   .af-title {
      color: #0c2a6b
   }

   .af-clear-all {
      border: 1px solid #cbd5e1;
      background: #f8fafc;
      padding: 6px 10px;
      border-radius: 999px;
      font-size: 13px;
      cursor: pointer;
      display: inline-block
   }

   .af-clear-all.is-disabled {
      opacity: .5;
      pointer-events: none
   }

   .af-body {
      display: flex;
      flex-direction: column;
      gap: 6px
   }

   .af-row {
      display: flex;
      align-items: flex-start;
      gap: 8px
   }

   .af-label {
      width: 100px;
      color: #0c2a6b;
      padding-top: 6px
   }

   .af-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 8px
   }

   .af-chip {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 6px 10px;
      border-radius: 999px;
      border: 1px solid #2f67d3;
      background: #eaf1ff;
      color: #0c2a6b;
      font-size: 14px;
      line-height: 1;
      text-decoration: none
   }

   .af-chip--gray {
      border-color: #cbd5e1;
      background: #f1f5f9;
      color: #334155
   }

   .af-chip--yellow {
      border-color: #f59e0b;
      background: #fff7e6;
      color: #92400e
   }

   .af-chip .af-x {
      font-weight: 700
   }

   .af-placeholder {
      color: #94a3b8;
      font-size: 14px;
      padding: 6px 0
   }
</style>