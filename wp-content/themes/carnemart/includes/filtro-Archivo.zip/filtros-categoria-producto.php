<?php

/**
 * Filtra productos por categoría y subcategoría
 * 
 * Modifica la consulta principal de WooCommerce para aplicar los filtros seleccionados
 * por el usuario (categorías, tipos de vino, países, paladar y rango de precios)
 * 
 * @param WP_Query $query Objeto de consulta WordPress
 */
function custom_filter_products_by_subcategories_and_taxonomies($query)
{
   if (!is_admin() && $query->is_main_query() && (is_product_category() || is_shop())) {
      $tax_query = $query->get('tax_query');
      if (!is_array($tax_query)) {
         $tax_query = array();
      }
      $meta_query = $query->get('meta_query', array());

      // Filtrar solo productos en stock
      $meta_query[] = array(
         'key' => '_stock_status',
         'value' => 'instock',
         'compare' => '='
      );

      $query->set('meta_query', $meta_query);
      // Procesar categorías
      if (!empty($_GET['categorias'])) {
         $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);

         $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $categorias,
            'operator' => 'IN',
         );
      }

      // Procesar tipos de vino
      if (!empty($_GET['tiposvino'])) {
         $tipos_vino = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);

         $tax_query[] = array(
            'taxonomy' => 'tipos_vino',
            'field'    => 'slug',
            'terms'    => $tipos_vino,
            'operator' => 'IN',
         );
      }

      // Procesar países
      if (!empty($_GET['pais_filtro'])) {
         $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);

         $tax_query[] = array(
            'taxonomy' => 'pais',
            'field'    => 'slug',
            'terms'    => $paises,
            'operator' => 'IN',
         );
      }

      if (!empty($_GET['paladar'])) {
         $paladar_values = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
         // Decodificar los valores de paladar
         $paladar_values = array_map('urldecode', $paladar_values);
         // Añadir meta query para paladar
         $meta_query = $query->get('meta_query', array());
         $meta_query[] = array(
            'key'     => 'paladar',
            'value'   => $paladar_values,
            'compare' => 'IN',
         );
         $query->set('meta_query', $meta_query);
      }

      if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
         $meta_query = $query->get('meta_query', array());

         $price_query = array('relation' => 'AND');

         if (!empty($_GET['min_price'])) {
            $price_query[] = array(
               'key'     => '_price',
               'value'   => floatval($_GET['min_price']),
               'compare' => '>=',
               'type'    => 'NUMERIC'
            );
         }

         if (!empty($_GET['max_price'])) {
            $price_query[] = array(
               'key'     => '_price',
               'value'   => floatval($_GET['max_price']),
               'compare' => '<=',
               'type'    => 'NUMERIC'
            );
         }

         $meta_query[] = $price_query;
         $query->set('meta_query', $meta_query);
      }

      if (!empty($_GET['variedad'])) {
         $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);

         $tax_query[] = array(
            'taxonomy' => 'variedad',
            'field'    => 'slug',
            'terms'    => $variedades,
            'operator' => 'IN',
         );
      }
      if (!empty($tax_query)) {
         $query->set('tax_query', $tax_query);
      }
   }
}
add_action('pre_get_posts', 'custom_filter_products_by_subcategories_and_taxonomies');

/**
 * Añade los parámetros de filtro a la URL de paginación
 * 
 * Asegura que los filtros seleccionados se mantengan al navegar entre páginas
 * 
 * @param string $link URL de la página de paginación
 * @return string URL modificada con los parámetros de filtro
 */
function custom_add_filter_params_to_pagination($link)
{
   $params = ['categorias', 'tiposvino', 'pais_filtro', 'paladar', 'min_price', 'max_price', 'variedad'];
   foreach ($params as $param) {
      if (!empty($_GET[$param])) {
         $link = remove_query_arg($param, $link);
         $value = is_array($_GET[$param]) ? implode(',', $_GET[$param]) : $_GET[$param];
         $link = add_query_arg($param, $value, $link);
      }
   }

   return $link;
}
add_filter('paginate_links', 'custom_add_filter_params_to_pagination');

/**
 * Obtiene los términos de tipos de vino filtrados
 * 
 * Recupera los términos de la taxonomía tipos_vino y actualiza sus conteos
 * basándose en los filtros activos
 * 
 * @return array Array de objetos término con conteos actualizados
 */
function get_filtered_tipos_vino_terms()
{
   $current_category = get_queried_object();
   $category_id = $current_category->term_id;

   // Construir tax_query base con la categoría actual
   $tax_query = array(
      array(
         'taxonomy' => 'product_cat',
         'field'    => 'term_id',
         'terms'    => $category_id,
         'operator' => 'IN',
      )
   );
   // Añadir filtros actuales a tax_query
   if (!empty($_GET['categorias'])) {
      $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
      $tax_query[] = array(
         'taxonomy' => 'product_cat',
         'field'    => 'slug',
         'terms'    => $categorias,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['pais_filtro'])) {
      $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);
      $tax_query[] = array(
         'taxonomy' => 'pais',
         'field'    => 'slug',
         'terms'    => $paises,
         'operator' => 'IN',
      );
   }
   // Preparar meta_query
   $meta_query = array();

   if (!empty($_GET['paladar'])) {
      $paladar_values = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
      $paladar_values = array_map('urldecode', $paladar_values);
      $meta_query[] = array(
         'key'     => 'paladar',
         'value'   => $paladar_values,
         'compare' => 'IN',
      );
   }

   if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
      $price_query = array('relation' => 'AND');

      if (!empty($_GET['min_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['min_price']),
            'compare' => '>=',
            'type'    => 'NUMERIC'
         );
      }

      if (!empty($_GET['max_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['max_price']),
            'compare' => '<=',
            'type'    => 'NUMERIC'
         );
      }

      $meta_query[] = $price_query;
   }
   if (!empty($_GET['variedad'])) {
      $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);
      $tax_query[] = array(
         'taxonomy' => 'variedad',
         'field'    => 'slug',
         'terms'    => $variedades,
         'operator' => 'IN',
      );
   }
   // Obtener todos los términos de tipos_vino
   $all_tipos_vino = get_terms(array(
      'taxonomy' => 'tipos_vino',
      'hide_empty' => false,
   ));

   $tipos_vino_with_count = array();

   foreach ($all_tipos_vino as $tipo) {
      // Clonar tax_query base y añadir el término actual
      $current_tax_query = $tax_query;
      $current_tax_query[] = array(
         'taxonomy' => 'tipos_vino',
         'field'    => 'term_id',
         'terms'    => $tipo->term_id,
      );

      // Contar productos que coinciden con todos los criterios
      $args = array(
         'post_type'      => 'product',
         'post_status'    => 'publish',
         'posts_per_page' => -1,
         'fields'         => 'ids',
         'tax_query'      => array(
            'relation' => 'AND',
            $current_tax_query
         ),
      );

      if (!empty($meta_query)) {
         $args['meta_query'] = $meta_query;
      }

      $products = new WP_Query($args);

      if ($products->found_posts > 0) {
         // Modificar el count del término
         $tipo->count = $products->found_posts;
         $tipos_vino_with_count[] = $tipo;
      }
   }

   return $tipos_vino_with_count;
}
/**
 * Obtiene los términos de países filtrados
 * 
 * Recupera los términos de la taxonomía pais y actualiza sus conteos
 * basándose en los filtros activos
 * 
 * @return array Array de objetos término con conteos actualizados
 */
function get_filtered_pais_terms()
{
   $current_category = get_queried_object();
   $category_id = $current_category->term_id;

   // Construir tax_query base con la categoría actual
   $tax_query = array(
      array(
         'taxonomy' => 'product_cat',
         'field'    => 'term_id',
         'terms'    => $category_id,
         'operator' => 'IN',
      )
   );

   if (!empty($_GET['categorias'])) {
      $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
      $tax_query[] = array(
         'taxonomy' => 'product_cat',
         'field'    => 'slug',
         'terms'    => $categorias,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['tiposvino'])) {
      $tipos_vino = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);
      $tax_query[] = array(
         'taxonomy' => 'tipos_vino',
         'field'    => 'slug',
         'terms'    => $tipos_vino,
         'operator' => 'IN',
      );
   }

   // Añadir meta_query para paladar y precios
   $meta_query = array();

   if (!empty($_GET['paladar'])) {
      $paladar_values = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
      $paladar_values = array_map('urldecode', $paladar_values);
      $meta_query[] = array(
         'key'     => 'paladar',
         'value'   => $paladar_values,
         'compare' => 'IN',
      );
   }

   if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
      $price_query = array('relation' => 'AND');

      if (!empty($_GET['min_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['min_price']),
            'compare' => '>=',
            'type'    => 'NUMERIC'
         );
      }

      if (!empty($_GET['max_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['max_price']),
            'compare' => '<=',
            'type'    => 'NUMERIC'
         );
      }

      $meta_query[] = $price_query;
   }
   if (!empty($_GET['variedad'])) {
      $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);
      $tax_query[] = array(
         'taxonomy' => 'variedad',
         'field'    => 'slug',
         'terms'    => $variedades,
         'operator' => 'IN',
      );
   }

   // Obtener todos los términos de pais
   $all_paises = get_terms(array(
      'taxonomy' => 'pais',
      'hide_empty' => false,
   ));

   $paises_with_count = array();

   foreach ($all_paises as $pais) {
      // Clonar tax_query base y añadir el término actual
      $current_tax_query = $tax_query;
      $current_tax_query[] = array(
         'taxonomy' => 'pais',
         'field'    => 'term_id',
         'terms'    => $pais->term_id,
      );

      // Contar productos que coinciden con todos los criterios
      $args = array(
         'post_type'      => 'product',
         'post_status'    => 'publish',
         'posts_per_page' => -1,
         'fields'         => 'ids',
         'tax_query'      => array(
            'relation' => 'AND',
            $current_tax_query
         ),
      );

      if (!empty($meta_query)) {
         $args['meta_query'] = $meta_query;
      }

      $products = new WP_Query($args);

      if ($products->found_posts > 0) {
         // Modificar el count del término
         $pais->count = $products->found_posts;
         $paises_with_count[] = $pais;
      }
   }

   return $paises_with_count;
}
/**
 * Obtiene los valores de paladar filtrados
 * 
 * Recupera los valores únicos del campo personalizado 'paladar' y sus conteos
 * basándose en los filtros activos
 * 
 * @return array Array de objetos similares a términos con conteos
 */
function get_filtered_paladar_terms()
{
   $current_category = get_queried_object();
   $category_id = $current_category->term_id;

   // Construir tax_query base con la categoría actual
   $tax_query = array(
      array(
         'taxonomy' => 'product_cat',
         'field'    => 'term_id',
         'terms'    => $category_id,
         'operator' => 'IN',
      )
   );

   if (!empty($_GET['categorias'])) {
      $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
      $tax_query[] = array(
         'taxonomy' => 'product_cat',
         'field'    => 'slug',
         'terms'    => $categorias,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['tiposvino'])) {
      $tipos_vino = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);
      $tax_query[] = array(
         'taxonomy' => 'tipos_vino',
         'field'    => 'slug',
         'terms'    => $tipos_vino,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['pais_filtro'])) {
      $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);
      $tax_query[] = array(
         'taxonomy' => 'pais',
         'field'    => 'slug',
         'terms'    => $paises,
         'operator' => 'IN',
      );
   }

   // Añadir meta_query para precios
   $meta_query = array();

   if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
      $price_query = array('relation' => 'AND');

      if (!empty($_GET['min_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['min_price']),
            'compare' => '>=',
            'type'    => 'NUMERIC'
         );
      }

      if (!empty($_GET['max_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['max_price']),
            'compare' => '<=',
            'type'    => 'NUMERIC'
         );
      }

      $meta_query[] = $price_query;
   }
   if (!empty($_GET['variedad'])) {
      $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);
      $tax_query[] = array(
         'taxonomy' => 'variedad',
         'field'    => 'slug',
         'terms'    => $variedades,
         'operator' => 'IN',
      );
   }
   // Obtener productos filtrados
   $args = array(
      'post_type'      => 'product',
      'post_status'    => 'publish',
      'posts_per_page' => -1,
      'fields'         => 'ids',
      'tax_query'      => array(
         'relation' => 'AND',
         $tax_query
      ),
   );

   if (!empty($meta_query)) {
      $args['meta_query'] = $meta_query;
   }
   $products = new WP_Query($args);
   $paladar_values = array();

   if ($products->have_posts()) {
      foreach ($products->posts as $product_id) {
         $paladar = get_field('paladar', $product_id);
         if (!empty($paladar)) {
            if (!isset($paladar_values[$paladar])) {
               $paladar_values[$paladar] = 1;
            } else {
               $paladar_values[$paladar]++;
            }
         }
      }
   }

   // Convertir a objetos similares a términos para mantener consistencia
   $paladar_terms = array();
   foreach ($paladar_values as $value => $count) {
      $paladar_terms[] = (object) array(
         'name' => $value,
         'slug' => sanitize_title($value),
         'count' => $count
      );
   }

   return $paladar_terms;
}
/**
 * Obtiene el rango de precios de los productos filtrados
 * 
 * Calcula el precio mínimo y máximo de los productos que coinciden
 * con los filtros activos
 * 
 * @return array Array asociativo con 'min' y 'max' como claves
 */
function get_filtered_price_range()
{
   $current_category = get_queried_object();
   $category_id = $current_category->term_id;

   // Construir tax_query base con la categoría actual
   $tax_query = array(
      array(
         'taxonomy' => 'product_cat',
         'field'    => 'term_id',
         'terms'    => $category_id,
         'operator' => 'IN',
      )
   );

   // Añadir filtros actuales a tax_query
   if (!empty($_GET['categorias'])) {
      $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
      $tax_query[] = array(
         'taxonomy' => 'product_cat',
         'field'    => 'slug',
         'terms'    => $categorias,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['tiposvino'])) {
      $tipos_vino = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);
      $tax_query[] = array(
         'taxonomy' => 'tipos_vino',
         'field'    => 'slug',
         'terms'    => $tipos_vino,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['pais_filtro'])) {
      $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);
      $tax_query[] = array(
         'taxonomy' => 'pais',
         'field'    => 'slug',
         'terms'    => $paises,
         'operator' => 'IN',
      );
   }

   // Preparar meta_query para paladar
   $meta_query = array();
   if (!empty($_GET['paladar'])) {
      $paladar_values = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
      $paladar_values = array_map('urldecode', $paladar_values);
      $meta_query[] = array(
         'key'     => 'paladar',
         'value'   => $paladar_values,
         'compare' => 'IN',
      );
   }

   // Obtener productos filtrados
   $args = array(
      'post_type'      => 'product',
      'posts_per_page' => -1,
      'post_status'    => 'publish',
      'fields'         => 'ids',
      'tax_query'      => array(
         'relation' => 'AND',
         $tax_query
      ),
   );

   // Añadir meta_query si existe
   if (!empty($meta_query)) {
      $args['meta_query'] = $meta_query;
   }
   if (!empty($_GET['variedad'])) {
      $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);
      $tax_query[] = array(
         'taxonomy' => 'variedad',
         'field'    => 'slug',
         'terms'    => $variedades,
         'operator' => 'IN',
      );
   }
   $products = new WP_Query($args);
   $prices = array(
      'min' => PHP_FLOAT_MAX,
      'max' => 0
   );

   if ($products->have_posts()) {
      foreach ($products->posts as $product_id) {
         $product = wc_get_product($product_id);
         $price = $product->get_price();
         if ($price) {
            $prices['min'] = min($prices['min'], $price);
            $prices['max'] = max($prices['max'], $price);
         }
      }
   }

   // Si no se encontraron precios, establecer valores predeterminados
   if ($prices['min'] === PHP_FLOAT_MAX) {
      $prices['min'] = 0;
   }

   return $prices;
}
/**
 * Obtiene el rango de precios de manera optimizada
 * 
 * Versión optimizada que utiliza consultas SQL directas para obtener
 * el rango de precios de los productos filtrados
 * 
 * @return array Array asociativo con 'min' y 'max' como claves
 */
function get_filtered_price_range_optimized()
{
   global $wpdb;

   $tax_query_sql = array();
   $meta_query_sql = array();

   // Construir condiciones base
   $tax_query_sql[] = $wpdb->prepare(
      "EXISTS (
            SELECT 1 FROM {$wpdb->term_relationships}
            INNER JOIN {$wpdb->term_taxonomy} ON {$wpdb->term_relationships}.term_taxonomy_id = {$wpdb->term_taxonomy}.term_taxonomy_id
            WHERE {$wpdb->term_taxonomy}.taxonomy = 'product_cat'
            AND {$wpdb->term_taxonomy}.term_id = %d
            AND {$wpdb->posts}.ID = {$wpdb->term_relationships}.object_id
        )",
      $current_category->term_id
   );

   // Añadir otros filtros si existen...

   $query = "
        SELECT MIN(CAST(price_meta.meta_value AS DECIMAL)) as min_price, 
               MAX(CAST(price_meta.meta_value AS DECIMAL)) as max_price
        FROM {$wpdb->posts}
        INNER JOIN {$wpdb->postmeta} price_meta ON {$wpdb->posts}.ID = price_meta.post_id
        WHERE {$wpdb->posts}.post_type = 'product'
        AND {$wpdb->posts}.post_status = 'publish'
        AND price_meta.meta_key = '_price'
        " . (!empty($tax_query_sql) ? "AND " . implode(' AND ', $tax_query_sql) : "") . "
        " . (!empty($meta_query_sql) ? "AND " . implode(' AND ', $meta_query_sql) : "");

   $prices = $wpdb->get_row($query);

   return array(
      'min' => $prices->min_price ?? 0,
      'max' => $prices->max_price ?? 0
   );
}
/**
 * Obtiene los términos de variedad filtrados
 * 
 * Recupera los términos de la taxonomía variedad y actualiza sus conteos
 * basándose en los filtros activos
 * 
 * @return array Array de objetos término con conteos actualizados
 */
function get_filtered_variedad_terms()
{
   $current_category = get_queried_object();
   $category_id = $current_category->term_id;

   // Construir tax_query base con la categoría actual
   $tax_query = array(
      array(
         'taxonomy' => 'product_cat',
         'field'    => 'term_id',
         'terms'    => $category_id,
         'operator' => 'IN',
      )
   );

   // Añadir filtros actuales a tax_query
   if (!empty($_GET['categorias'])) {
      $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
      $tax_query[] = array(
         'taxonomy' => 'product_cat',
         'field'    => 'slug',
         'terms'    => $categorias,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['tiposvino'])) {
      $tipos_vino = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);
      $tax_query[] = array(
         'taxonomy' => 'tipos_vino',
         'field'    => 'slug',
         'terms'    => $tipos_vino,
         'operator' => 'IN',
      );
   }

   if (!empty($_GET['pais_filtro'])) {
      $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);
      $tax_query[] = array(
         'taxonomy' => 'pais',
         'field'    => 'slug',
         'terms'    => $paises,
         'operator' => 'IN',
      );
   }

   // Añadir meta_query para paladar y precios
   $meta_query = array();

   if (!empty($_GET['paladar'])) {
      $paladar_values = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
      $paladar_values = array_map('urldecode', $paladar_values);
      $meta_query[] = array(
         'key'     => 'paladar',
         'value'   => $paladar_values,
         'compare' => 'IN',
      );
   }

   if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
      $price_query = array('relation' => 'AND');

      if (!empty($_GET['min_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['min_price']),
            'compare' => '>=',
            'type'    => 'NUMERIC'
         );
      }

      if (!empty($_GET['max_price'])) {
         $price_query[] = array(
            'key'     => '_price',
            'value'   => floatval($_GET['max_price']),
            'compare' => '<=',
            'type'    => 'NUMERIC'
         );
      }

      $meta_query[] = $price_query;
   }

   // Obtener todos los términos de variedad
   $all_variedades = get_terms(array(
      'taxonomy' => 'variedad',
      'hide_empty' => false,
   ));

   $variedades_with_count = array();

   foreach ($all_variedades as $variedad) {
      // Clonar tax_query base y añadir el término actual
      $current_tax_query = $tax_query;
      $current_tax_query[] = array(
         'taxonomy' => 'variedad',
         'field'    => 'term_id',
         'terms'    => $variedad->term_id,
      );

      // Contar productos que coinciden con todos los criterios
      $args = array(
         'post_type'      => 'product',
         'post_status'    => 'publish',
         'posts_per_page' => -1,
         'fields'         => 'ids',
         'tax_query'      => array(
            'relation' => 'AND',
            $current_tax_query
         ),
      );

      if (!empty($meta_query)) {
         $args['meta_query'] = $meta_query;
      }

      $products = new WP_Query($args);

      if ($products->found_posts > 0) {
         // Modificar el count del término
         $variedad->count = $products->found_posts;
         $variedades_with_count[] = $variedad;
      }
   }

   return $variedades_with_count;
}

/**
 * Registra el script de filtros de categorías
 * 
 * Encola el archivo JavaScript necesario para el funcionamiento
 * de los filtros en el frontend
 */
add_action('wp_enqueue_scripts', 'enqueue_filtros_categorias_js');
function enqueue_filtros_categorias_js()
{
   // Evitar cache js
   $version = time();

   wp_enqueue_script('filtros-categorias', get_template_directory_uri() . '/js/filtros-categorias.js', array('jquery'), $version, true);
}
/**
 * Añade la clase woocommerce al body en resultados de búsqueda
 * 
 * Agrega la clase 'woocommerce' al body cuando hay productos
 * en los resultados de búsqueda
 * 
 * @param array $classes Array de clases del body
 * @return array Array modificado de clases
 */
function add_woocommerce_class_to_search_body($classes)
{
   if (is_search()) {
      global $wp_query;
      // Check if there are any products in search results
      foreach ($wp_query->posts as $post) {
         if ($post->post_type === 'product') {
            $classes[] = 'woocommerce';
            break;
         }
      }
   }
   return $classes;
}
add_filter('body_class', 'add_woocommerce_class_to_search_body');
