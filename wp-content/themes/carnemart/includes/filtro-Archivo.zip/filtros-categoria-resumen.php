<?php

if (
   !empty($_GET['categorias']) || !empty($_GET['tiposvino']) || !empty($_GET['pais_filtro']) ||
   !empty($_GET['paladar']) || !empty($_GET['min_price']) || !empty($_GET['max_price']) || !empty($_GET['variedad'])
) : ?>

   <div class="filter-container filtros-activos">
      <div class="filter-title">
         Filtros Activos
      </div>
      <div class="filtros-resumen">
         <?php
         if (!empty($_GET['categorias'])) {
            echo "<div class='filter-title'>Categorias</div>";
            $categorias = is_array($_GET['categorias']) ? $_GET['categorias'] : explode(',', $_GET['categorias']);
            $cat_terms = get_terms(array(
               'taxonomy' => 'product_cat',
               'slug' => $categorias,
               'hide_empty' => true
            ));
            foreach ($cat_terms as $term) {
               echo '<span class="filtro-tag"> - ' . esc_html($term->name) . '</span><br/>';
            }
         }

         if (!empty($_GET['tiposvino'])) {
            echo "<div class='filter-title'>Tipo de bebida</div>";
            $tipos = is_array($_GET['tiposvino']) ? $_GET['tiposvino'] : explode(',', $_GET['tiposvino']);
            $tipo_terms = get_terms(array(
               'taxonomy' => 'tipos_vino',
               'slug' => $tipos,
               'hide_empty' => true
            ));
            foreach ($tipo_terms as $term) {
               echo '<span class="filtro-tag"> - ' . esc_html($term->name) . '</span><br/>';
            }
         }

         if (!empty($_GET['pais_filtro'])) {
            echo "<div class='filter-title'>País</div>";
            $paises = is_array($_GET['pais_filtro']) ? $_GET['pais_filtro'] : explode(',', $_GET['pais_filtro']);
            $pais_terms = get_terms(array(
               'taxonomy' => 'pais',
               'slug' => $paises,
               'hide_empty' => true
            ));
            foreach ($pais_terms as $term) {
               echo '<span class="filtro-tag"> - ' . esc_html($term->name) . '</span><br/>';
            }
         }
         if (!empty($_GET['paladar'])) {
            echo "<div class='filter-title'>Paladar</div>";
            $paladar = is_array($_GET['paladar']) ? $_GET['paladar'] : explode(',', $_GET['paladar']);
            $paladar = array_map('urldecode', $paladar);
            foreach ($paladar as $valor) {
               echo '<span class="filtro-tag"> - ' . esc_html($valor) . '</span><br/>';
            }
         }

         // Mostrar rango de precios activo
         if (!empty($_GET['min_price']) || !empty($_GET['max_price'])) {
            echo "<div class='filter-title'>Rango de Precios</div>";
            $min_price = !empty($_GET['min_price']) ? floatval($_GET['min_price']) : 0;
            $max_price = !empty($_GET['max_price']) ? floatval($_GET['max_price']) : PHP_FLOAT_MAX;
            echo '<span class="filtro-tag"> - $' .
               number_format($min_price, 0, '.', ',') . ' - $' .
               number_format($max_price, 0, '.', ',') .
               '</span><br/>';
         }
         ?>

         <?php

         if (!empty($_GET['variedad'])) {
            echo "<div class='filter-title'>Variedad</div>";
            $variedades = is_array($_GET['variedad']) ? $_GET['variedad'] : explode(',', $_GET['variedad']);
            $variedad_terms = get_terms(array(
               'taxonomy' => 'variedad',
               'slug' => $variedades,
               'hide_empty' => true
            ));
            foreach ($variedad_terms as $term) {
               echo '<span class="filtro-tag"> - ' . esc_html($term->name) . '</span><br/>';
            }
         }
         ?>
      </div>
      <?php
      if (is_shop()) {
         $base_url = get_permalink(wc_get_page_id('shop'));
      } elseif ($current_category && isset($current_category->term_id)) {
         $base_url = get_term_link($current_category->term_id);
      }
      ?>
      <a href="<?php echo esc_url($base_url); ?>" class="cta-inline mt-3">Borrar filtros</a>
   </div>
<?php endif; ?>